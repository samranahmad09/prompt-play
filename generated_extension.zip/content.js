// Not required for blocking (DNR handles it). Reserved for future UI features.
